def lambda_handler(event, context):
    # Your Lambda function logic here
    return {
        'statusCode': 200,
        'body': 'Hello from Lambda!'
    }
